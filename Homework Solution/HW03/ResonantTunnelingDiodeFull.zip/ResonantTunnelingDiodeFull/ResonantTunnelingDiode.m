%ResonantTunnelingDiode.m
%
%This script calculates the transmission of a model resonant tunneling
%diode potential. Solution to "Resonant Tunneling Diode" PHY308 problem.
%
%Tom Allison 1/11/2017

%% Preliminaries
set(0,'DefaultLineLineWidth',2);
i = sqrt(-1);

% Work in units where length is measured in Angstrom and Energy in eV.
E = 0.1; %Incident electron energy in eV.
a = 10;
b = 50;
hb2ov2m = 3.81; % hbar^2/2m_e in units of eV-Angstrom^2

Vb = 0.2;
V0 = linspace(0,2,1000); % bias potential in 30 steps between 0 and 2 eV. 

k1 = sqrt(E/hb2ov2m);
kap2 = sqrt((Vb-E)/hb2ov2m);
k3 = sqrt((E+V0/2)/hb2ov2m);  % this one and the ones below will be an array because V0 is an array.
kap4 = sqrt((Vb-E-V0/2)/hb2ov2m);
k5 = sqrt( (E+V0)/hb2ov2m );

VOUT = zeros(8,length(E));
T = zeros(1,length(E));
R = zeros(1,length(E));
detM = zeros(1,length(E));

%% Calculate coefficients at each bias potential.

for j = 1:length(V0);
    M = [-1             1                           1                       0                           0                               0                               0                               0;
        i*k1            -kap2                       kap2                   0                           0                               0                               0                               0;
        0               exp(-kap2*a)                exp(kap2*a)            -exp(i*k3(j)*a)              -exp(-i*k3(j)*a)                 0                               0                               0;  
        0               -kap2*exp(-kap2*a)          kap2*exp(kap2*a)       -i*k3(j)*exp(i*k3(j)*a)     i*k3(j)*exp(-i*k3(j)*a)         0                               0                               0;
        0               0                           0                       exp(i*k3(j)*(a+b))          exp(-i*k3(j)*(a+b))             -exp(-kap4(j)*(a+b))           -exp(kap4(j)*(a+b))               0;
        0               0                           0                       i*k3(j)*exp(i*k3(j)*(a+b))  -i*k3(j)*exp(-i*k3(j)*(a+b))    kap4(j)*exp(-kap4(j)*(a+b))    -kap4(j)*exp(kap4(j)*(a+b))       0;
        0               0                           0                       0                           0                               exp(-kap4(j)*(2*a+b))           exp(kap4(j)*(2*a+b))            -exp(i*k5(j)*(2*a+b));
        0               0                           0                       0                           0                               -kap4(j)*exp(-kap4(j)*(2*a+b))  kap4(j)*exp(kap4(j)*(2*a+b))    -i*k5(j)*exp(i*k5(j)*(2*a+b))];
        
    VRHS = [1;
            i*k1;
            0;
            0;
            0;
            0;
            0;
            0];

VOUT(:,j) = inv(M)*VRHS; % assign the jth row to be the solution for energy E(j);

R(j) = VOUT(1,j)*conj(VOUT(1,j));
T(j) = 1-R(j);
detM(j) = det(M);

end

% plot the wavefunction for a selected point.
Iplot = 71;
Vplot = VOUT(:,Iplot);
x = linspace(-100,2*a+b+100,1E4);
psi = zeros(1,length(x));
V = zeros(1,length(x));

%% Construct psi

I = find(x<0);
psi(I) = exp(i*k1*x(I)) + Vplot(1)*exp(-i*k1*x(I));
V(I) = 0;
I = find(x >= 0 & x < a);
psi(I) = Vplot(2)*exp(-kap2*x(I)) + Vplot(3)*exp(kap2*x(I));
V(I) = Vb;
I = find(x >= a & x < a+b);
psi(I) = Vplot(4)*exp(i*k3(Iplot)*x(I)) + Vplot(5)*exp(-i*k3(Iplot)*x(I));
V(I) = -V0(Iplot)/2;
I = find(x >= a+b & x < 2*a+b);
psi(I) = Vplot(6)*exp(-kap4(Iplot)*x(I)) + Vplot(7)*exp(kap4(Iplot)*x(I));
V(I) = -V0(Iplot)/2 + Vb;
I = find(x >= 2*a+b);
psi(I) = Vplot(8)*exp(i*k5(Iplot)*x(I));
V(I) = -V0(Iplot);

%% Plot Results

figure(1);
hV = plot(x,V,'k','LineWidth',3);
hold on
hr = plot(x,real(psi)/3); % divide by 3 just for scale.
him = plot(x,imag(psi)/3);
hold off
xlabel('x');
grid on
title(['Wave Function with V_0 = ',num2str(V0(Iplot)), ' eV']);
ylabel('V(x)');
xlabel('x [angstrom]');
%setfigfont(gcf,14);


figure(2);
%TfromJ = (k5/k1).*VOUT(8,:).*conj(VOUT(8,:)); Can also calculate transmission from wave function in amplitude in region V, but mind the prob. current!!! 

hT = plot(V0,T);
hold on
hR = plot(V0,R);
%hT = plot(V0,TfromJ,'r--');
hold off
legend([hT,hR],'Transmission','Reflection');
grid on
xlabel('V_0 [eV]');
ylabel('R and T');
%setfigfont(gcf,14)

% %% Extra stuff to plot if desired. 
% % plot the potential V0 = 1 eV.
% [crap,I1] = min(abs(V0-0.3));
% V1 = VOUT(:,I1);
% x = linspace(-100,2*a+b+100,1E4);
% V1 = zeros(1,length(x));
% 
% %% Construct psi
% 
% I = find(x<0);
% V1(I) = 0;
% I = find(x >= 0 & x < a);
% V1(I) = Vb;
% I = find(x >= a & x < a+b);
% V1(I) = -V0(I1)/2;
% I = find(x >= a+b & x < 2*a+b);
% V1(I) = -V0(I1)/2 + Vb;
% I = find(x >= 2*a+b);
% V1(I) = -V0(I1);
% 
% figure(10);
% plot(x,V1,'k','LineWidth',3);
% xlabel('x [angstrom]');
% ylabel('V [eV]');
% grid on
% setfigfont(gcf,14);
% axis([-25,100,-0.4,0.3]);
% 


% figure(3);
% plot(V0,real(detM));
% hold on
% plot(V0,imag(detM));
% hold off
% xlabel('V_0 [eV]');
% ylabel('Determinant');
% grid on

% %% Does it solve the Schrodinger equation?
% psi1 = diff(psi)./diff(x)
% x1 = (x(1:end-1) + x(2:end))/2;
% psi2 = diff(psi1)./diff(x1);
% x2 = (x1(1:end-1) + x1(2:end))/2;
% 
% LHS = -hb2ov2m*psi2 + V(2:end-1).*psi(2:end-1);
% RHS = E*psi(2:end-1);
% figure(4);
% subplot(3,1,1);
% plot(x2,real(LHS-RHS));
% hold on
% plot(x2,imag(LHS-RHS));
% hold off
% grid on
% xlabel('x [angstrom]');
% ylabel('RHS-LHS of TISE');
% 
% subplot(3,1,2);
% plot(x2,real(RHS));
% xlabel('x [angstrom]');
% ylabel('RHS');

% subplot(3,1,3);
% plot(x2,real(LHS));
% xlabel('x [angstrom]');
% ylabel('RHS');
%
% is first derivative continuous.
% figure(5);
% plot(x1,psi1);