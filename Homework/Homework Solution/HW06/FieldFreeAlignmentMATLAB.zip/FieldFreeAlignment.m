%FieldFreeAlignment.m
%
%This script calculates expectation values of cos^2(theta) for a rotational
%wavepacket. Uses function Ylm.m 
%
%Tom Allison 8/10/2013

%% Preliminatries

set(0,'DefaultLineLineWidth',2);

i = sqrt(-1);

c = 3E10; %speed of light in cm/s
Bcm = 1.9896; % rotational constant in wavenumbers
BHz = c*Bcm; % rotational constant in Hz.
Binvps = BHz*1E-12; % Rotational constant in 1/10 Hz.

theta = linspace(0,pi); %linear array in theta
t = linspace(0,10,500); %linear array in time, spanning one to 10 ps. Units of ps
psi = zeros(length(t),length(theta));

J = (0:1:10)'; % needs to be a column vector so fancy matrix multiplication works out later.

psi_J = zeros(length(J),length(theta)); % initialize psi_J, a matrix containing all the wavefunctions
psi_t = zeros(length(t),length(theta)); %initialize psi_t, a matrix where each row is the wave function at a different time
psi2 = zeros(length(t),length(theta)); %initialize psi2, the square modulus of psi_t
cos2th = zeros(length(t),1); % initialize array for recording <cos^2(th)> at each time step.

%% Construct initially phased rotational states
for k = 1:length(J)
    psi_J(k,:) = Ylm(J(k),0,theta,0)*exp(i*pi/4*J(k)); %phi is irrelevant because everything is azimuthally symmetric for m=0
end

%% Calculate time dependent superposition and expectation value of cos^2(theta)

for k = 1:length(t)
    if length(J) > 1 % handle the exception of only one rotational state
        % do sneaky matrix multiplications to multiply each row by its appropriate phase factor
        phasemat = exp(-i*2*pi*Binvps*(J.*(J+1))*ones(1,length(theta))*t(k));
        psi_t(k,:) = 1/sqrt(length(J))*sum(phasemat.*psi_J);
    else
        psi_t(k,:) = psi_J; %if only one rotational state, there will be no time dependence
    end
    psi2(k,:) = psi_t(k,:).*conj(psi_t(k,:)); %\psi^2
    cos2th(k) = 2*pi*(theta(2)-theta(1))*trapz(sin(theta).*psi2(k,:).*cos(theta).^2);
end

%% Plot Results
figure(1);
plot(t,cos2th,'k');
grid on
xlabel('t [ps]');
ylabel('<cos^2(\theta)>');

%% Part c) Discussion
% The molecule experiences a full "revival", where the wavefunction repeats
% itself at h/(2B) ~ 8.4 ps. "Fractional revivals" at fractions of the
% revival time also show transient alignment. The width of the alignment
% peaks is only about 0.3 ps, so any experiment that is be done on these
% aligned molecules must be done very quickly!!!
%
% The results of the simple superposition wave function compare nicely to
% the real experimental data of Litvinyuk et al. The real wavefunction will
% be somewhat more complicated because of the selection rules of Raman
% excitation and the initial thermal ensemble.

