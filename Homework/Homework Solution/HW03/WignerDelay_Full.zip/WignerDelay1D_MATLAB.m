%WignerDelay1D.m
%
%This plots the phase shifts for the 1D scattering problem in Griffiths
%problem 11.5.
%
%Tom Allison 9/25/2017

%% Preliminaries
set(0,'DefaultLineLineWidth',2);

i = sqrt(-1);
hbar = 1;
m = 1;
a = 1;
E = hbar^2/(m*a^2)*linspace(0.1,100,500);
V0 = 30*hbar^2/(m*a^2);

k = sqrt(2*m*E)/hbar;
kp = sqrt(2*m*(E-V0))/hbar;

% calculate classical lower limit on Wigner delay
vg = hbar*k/m; % Group velocity for a free particle in the potential free region.
TauClass = -a./vg; % 

B = exp(-2*i*k*a).*(k-i*kp.*cot(kp*a))./(k+i*kp.*cot(kp*a)); % Equation from Griffiths.

delta = 1/2*unwrap(angle(-B));
Tau_W = hbar*diff(delta)./diff(E); % Wigner delay from numerical derivative.
E1 = (E(1:end-1)+E(2:end))/2; %x-axis for derivative.

% calculate resonances from simple formula.
n = 1:20;
if V0 < 0;
    Eres = (n*pi + pi/2).^2*hbar^2/(2*m*a^2) + V0;
else
    Eres = (n*pi).^2*hbar^2/(2*m*a^2) + V0;
end

I = find(Eres>0);
Eres = Eres(I);

%% Plot Results
figure(1);
subplot(3,1,1)
hr = plot(E,real(B));
hold on
hi = plot(E,imag(B));
habs = plot(E,abs(B));
hold off
grid on
legend([hr,hi,habs],'real part','imaginar part','|r|');
xlabel('E [$\hbar^2/ma^2$]','Interpreter','latex')
ylabel('Reflection Coefficient');
title(['Scattering Potential = ',num2str(V0),', Barrier Width = ' num2str(a)]);

subplot(3,1,2);
plot(E,delta);
xlabel('E [$\hbar^2/ma^2$]','Interpreter','latex')
ylabel('\delta [rad]');
grid on

subplot(3,1,3);
hTau_W = plot(E1,Tau_W);
hold on
hTau_Classical = plot(E,TauClass);
%plot resonances (requires vline.m)
j = 1;
while Eres(j) < max(E);
   vline(gcf,Eres(j),'k--');
   j = j+1;
end
hold off
grid on
xlabel('E [$\hbar^2/ma^2$]','Interpreter','latex')
ylabel('Wigner Delay [$ma^2/\hbar$]','Interpreter','latex');
legend([hTau_W,hTau_Classical],'Wigner Delay Calculated From Phase Shift',...
    'Classical Lower Limit');
% setfigfont(1,14);

%% Interpretation
%
% The group velocity for a free particle with central momentum k is
% vg = hbar*k/m. The least amount of time the particle could spend inside the
% scattering region -a < x < 0 is no time at all if it completely reflected
% off the front of the region at x = -a. This corresponds to a "delay" 
%(really an advance in time) of -a/vg. This is the minimum value of the
%Wigner delay that satisfies causality (particle cannot be reflected before
%it arrives).



