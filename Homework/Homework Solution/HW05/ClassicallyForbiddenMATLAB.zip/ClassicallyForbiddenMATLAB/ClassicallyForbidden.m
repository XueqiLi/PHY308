%ClassicallyForbiddenRegion.m
%
%This script calculates the probability of finding a harmonic oscillator in
%its classically forbidden region and also makes some nice plots.
%
%Tom Allison 8/26/2013

%% Initialize and Calculate

set(0,'DefaultLineLineWidth',2);
N = 10; % number of wavefunctions to plot
xi = linspace(-2*sqrt(N),2*sqrt(N),1E4); %xi axis

%initialize arrays to calculate in for loop.
psi_n = zeros(N,length(xi)); 
psi_nplot = zeros(N,length(xi));
psi_nsq = zeros(N,length(xi));
Pforb = zeros(N,1);
xiforb = zeros(N,1);
Pclass = zeros(N,length(xi));

for n = 1:N
    psi_n(n,:) = pi^(-1/4)*1/(sqrt(2^(n-1)*factorial(n-1)))...
        *polyval(HermitePoly(n-1),xi).*exp(-xi.^2/2);
    psi_nsq(n,:) = psi_n(n,:).*conj(psi_n(n,:)); %square modulus of wavefunction
    psi_nplot(n,:) = psi_n(n,:) + 1 + 2*(n-1);
    xiforb(n) = sqrt(2*(n-1+1/2));        %boundary of the classically forbidden region in xi
    [crap,I] = min(abs(xi-xiforb(n))); % find index closest to forbidden region
    Pforb(n) = 2*(xi(2)-xi(1))*trapz(psi_nsq(n,I:end)); %integrate to \psi^2 to find probability of particle being in forbidden region
                                                        %multiply by 2 to
                                                        %account for +x and
                                                        %-x.
                                                                                                                                                                   
    % construct classical probability distribution
    Pclass(n,:) = 2*1./(2*pi*xiforb(n))*1./sqrt(1-(xi/xiforb(n)).^2); % analytic expression from SHO equations. 
    I = find(abs(xi)>=xiforb(n));
    Pclass(n,I) = 0;
end

%% plot wavefunctions

figure(1);
plot(xi,psi_nplot,'r');
hold on
plot(xi,xi.^2,'k');;
for n= 1:N;
    hline(gcf,1+2*(n-1),'k--');
end    
hold off
xlabel('\xi');
ylabel('\psi_n');
set(gca,'YTickLabel',[]);
set(gca,'Xgrid','on');
axis([xlim,0,2.2*N]);

%% Plot probability of being found in classicaly forbidden region
% The probability of being in the forbidden region decreases rapidly as the 
% quantum number and energy increases and the system behaves "more
% classically".

figure(2);
plot((1:N)-1,Pforb,'o-');
xlabel('n');
ylabel('Probability of finding particle in forbidden region');
grid on

%% Plot quantum vs. classical probability for n=0 and n=N

figure(3);
numplot = 9
hquant = plot(xi,psi_nsq(numplot+1,:),'k');
hold on
hclass = plot(xi,smooth(Pclass(10,:),4),'g');
hold off
grid on
xlabel('x');
ylabel('Probability Density');
legend([hclass,hquant],'Classical','Quantum');
title(['Results for n = ',num2str(numplot)])

%% Part b)
% Wave function has no nodes in the forbidden region because the local 
% wavevector is approximately
% 
% $$k \sim \sqrt{2(E-V)/m}$$
% 
% and for $E > V$ (allowed region) k is real and $e^{ikx}$ is oscillatory
% and wavelike. But for $E< V$, k is imaginary and $e^{ikx} = e^{-kx}$ is
% an exponential decay with no oscillations.




